README
==

This project is my answer to the Mac challenge. It should build and run on Xcode 13 / Mac OS 12 Monterey. 

Thanks!

Rob Mooney<br>[robertm16@mac.com](robertm16@mac.com)