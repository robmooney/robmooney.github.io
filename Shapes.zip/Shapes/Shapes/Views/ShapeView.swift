// Created by Robert Mooney.
// Copyright © 2021 Robert Mooney.

import Cocoa

class ShapeView: NSView {
  var shape: Shape {
    didSet {
      frame = shape.frame
      setNeedsDisplay(bounds)
    }
  }

  init(shape: Shape) {
    self.shape = shape
    super.init(frame: shape.frame)
  }

  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  override func draw(_ dirtyRect: NSRect) {
    super.draw(dirtyRect)

    NSGraphicsContext.saveGraphicsState()
    defer {
      NSGraphicsContext.restoreGraphicsState()
    }

    NSColor.controlAccentColor.setStroke()
    shape.color.nsColor.setFill()

    switch shape.type {
    case .rect:
      NSBezierPath.fill(bounds)
      if shape.isSelected {
        let path = NSBezierPath(rect: bounds.insetBy(dx: 1, dy: 1))
        path.lineWidth = 2
        path.stroke()
      }
    case .ellipse:
      NSBezierPath(ovalIn: bounds).fill()
      if shape.isSelected {
        let path = NSBezierPath(ovalIn: bounds.insetBy(dx: 1, dy: 1))
        path.lineWidth = 2
        path.stroke()
      }
    }
  }
}
