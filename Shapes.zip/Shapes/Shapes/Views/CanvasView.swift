// Created by Robert Mooney.
// Copyright © 2021 Robert Mooney.

import Cocoa

protocol CanvasViewDelegate: AnyObject {
  func canvasView(_ canvasView: CanvasView, didAddShape shape: Shape)
  func canvasView(_ canvasView: CanvasView, didMouseDownOnShape shape: Shape)
  func canvasView(_ canvasView: CanvasView, didDragShape shape: Shape)
}

class CanvasView: NSView {
  weak var delegate: CanvasViewDelegate?

  private var shapeViews: [ShapeView] {
    subviews as! [ShapeView]
  }

  private var draggedShapeView: ShapeView?
  private var dragOffset: NSSize?
  private var initialDragLocation: NSPoint?

  override var isFlipped: Bool {
    true
  }

  var shapes: [Shape] = [] {
    didSet {
      for (i, shape) in shapes.enumerated() {
        if i < shapeViews.count {
          let shapeView = shapeViews[i]
          if shapeView.shape != shape {
            shapeView.shape = shape
          }
        } else {
          let shapeView = ShapeView(shape: shape)
          addSubview(shapeView)
          draggedShapeView = shapeView
        }
      }
    }
  }

  override func draw(_ dirtyRect: NSRect) {
    super.draw(dirtyRect)

    NSColor.white.setFill()
    NSBezierPath.fill(dirtyRect)
  }

  override func mouseDown(with event: NSEvent) {
    if let shapeView = hitTest(event.locationInWindow) as? ShapeView {
      draggedShapeView = shapeView
      dragOffset = .init(width: shapeView.frame.origin.x - event.locationInWindow.x, height: shapeView.frame.origin.y - event.locationInWindow.y)
      initialDragLocation = event.locationInWindow
      delegate?.canvasView(self, didMouseDownOnShape: shapeView.shape)
    } else {
      let location = convert(event.locationInWindow, from: nil)
      let shape = Shape.random(at: location)

      dragOffset = .init(width: shape.frame.origin.x - event.locationInWindow.x, height: shape.frame.origin.y - event.locationInWindow.y)
      initialDragLocation = event.locationInWindow

      delegate?.canvasView(self, didAddShape: shape)
      delegate?.canvasView(self, didMouseDownOnShape: shape)
    }
  }

  override func mouseDragged(with event: NSEvent) {
    guard let draggedShapeView = draggedShapeView,
          let dragOffset = dragOffset,
          let initialDragLocation = initialDragLocation else {
      return
    }

    let xOffset = event.locationInWindow.x - initialDragLocation.x
    let yOffset = event.locationInWindow.y - initialDragLocation.y

    var draggedShape = draggedShapeView.shape
    draggedShape.frame.origin.x = initialDragLocation.x + xOffset + dragOffset.width
    draggedShape.frame.origin.y = initialDragLocation.y - yOffset + dragOffset.height

    delegate?.canvasView(self, didDragShape: draggedShape)
  }

  override func mouseUp(with event: NSEvent) {
    draggedShapeView = nil
    dragOffset = nil
    initialDragLocation = nil
  }
}
