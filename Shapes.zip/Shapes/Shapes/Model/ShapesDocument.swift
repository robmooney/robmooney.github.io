// Created by Robert Mooney.
// Copyright © 2021 Robert Mooney.

import Cocoa

class ShapesDocument: NSDocument {
  var shapes: [Shape] = []

  override class var autosavesInPlace: Bool {
    return true
  }

  override func makeWindowControllers() {
    // Returns the Storyboard that contains your Document window.
    let storyboard = NSStoryboard(name: NSStoryboard.Name("Main"), bundle: nil)
    let windowController = storyboard.instantiateController(withIdentifier: NSStoryboard.SceneIdentifier("Document Window Controller")) as! NSWindowController
    addWindowController(windowController)

    windowController.contentViewController?.representedObject = self
  }

  override func data(ofType typeName: String) throws -> Data {
    try JSONEncoder().encode(shapes)
  }

  override func read(from data: Data, ofType typeName: String) throws {
    shapes = try JSONDecoder().decode([Shape].self, from: data)
  }
}

