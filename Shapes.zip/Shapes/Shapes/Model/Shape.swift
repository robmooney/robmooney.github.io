// Created by Robert Mooney.
// Copyright © 2021 Robert Mooney.

import Cocoa

enum ShapeType: String {
  case rect, ellipse
}

struct Color {
  var red: CGFloat
  var green: CGFloat
  var blue: CGFloat
}

struct Shape {
  var id: UUID
  var type: ShapeType
  var frame: NSRect
  var color: Color
  var isSelected: Bool
}

extension ShapeType: Equatable, Codable { }

extension Color: Equatable, Codable { }

extension Shape: Equatable, Codable { }

extension ShapeType {
  static func random() -> Self {
    if Bool.random() {
      return .rect
    } else {
      return .ellipse
    }
  }
}

extension NSSize {
  static func random(minSize: Self, maxSize: Self) -> Self {
    .init(
      width: .random(in: minSize.width ... maxSize.width),
      height: .random(in: minSize.height ... maxSize.height)
    )
  }
}

extension Color {
  static func random() -> Self {
    .init(red: .random(in: 0 ... 1), green: .random(in: 0 ... 1), blue: .random(in: 0 ... 1))
  }
}

extension Shape {
  static func random(at location: NSPoint, minSize: NSSize = .init(width: 40, height: 40), maxSize: NSSize = .init(width: 150, height: 150)) -> Self {
    var shape = Shape(
      id: UUID(),
      type: .random(),
      frame: .init(origin: location, size: .random(minSize: minSize, maxSize: maxSize)),
      color: .random(),
      isSelected: false
    )
    shape.frame = shape.frame.offsetBy(dx: -(shape.frame.width / 2), dy: -(shape.frame.height / 2))

    return shape
  }
}

extension Color {
  var nsColor: NSColor {
    .init(red: red, green: green, blue: blue, alpha: 1)
  }
}

extension NSColor {
  var shapesColor: Color {
    .init(red: redComponent, green: greenComponent, blue: blueComponent)
  }
}
