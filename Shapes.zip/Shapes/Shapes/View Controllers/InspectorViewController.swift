// Created by Robert Mooney.
// Copyright © 2021 Robert Mooney.

import Cocoa

protocol InspectorViewControllerDelgate: AnyObject {
  func inspectorViewControllerSelectedShapeDidChange(_ inspectorViewController: InspectorViewController)
}

class InspectorViewController: NSViewController {
  weak var delegate: InspectorViewControllerDelgate?

  @IBOutlet weak var inspectorView: NSGridView!
  @IBOutlet weak var xField: NSTextField!
  @IBOutlet weak var yField: NSTextField!
  @IBOutlet weak var widthField: NSTextField!
  @IBOutlet weak var heightField: NSTextField!
  @IBOutlet weak var colorWell: NSColorWell!

  var shapesDocument: ShapesDocument {
    get {
      representedObject as! ShapesDocument
    }
    set {
      representedObject = newValue
    }
  }

  var selectedShape: Shape? {
    shapesDocument.shapes.first {
      $0.isSelected
    }
  }

  override func viewDidLoad() {
    super.viewDidLoad()

    (xField.formatter as? NumberFormatter)?.maximumFractionDigits = 0
    (yField.formatter as? NumberFormatter)?.maximumFractionDigits = 0
    (widthField.formatter as? NumberFormatter)?.maximumFractionDigits = 0
    (heightField.formatter as? NumberFormatter)?.maximumFractionDigits = 0
  }

  override var representedObject: Any? {
    didSet {
      updateView()
    }
  }

  func updateView() {
    if let selectedShape = selectedShape {
      inspectorView.isHidden = false
      xField.stringValue = "\(selectedShape.frame.minX)"
      yField.stringValue = "\(selectedShape.frame.minY)"
      widthField.stringValue = "\(selectedShape.frame.width)"
      heightField.stringValue = "\(selectedShape.frame.height)"
      colorWell.color = selectedShape.color.nsColor
    } else {
      inspectorView.isHidden = true
    }
  }

  @IBAction func frameValueUpdated(_ sender: NSTextField) {
    guard var selectedShape = self.selectedShape else {
      return
    }

    if sender == xField {
      selectedShape.frame.origin.x = sender.doubleValue
    }

    if sender == yField {
      selectedShape.frame.origin.y = sender.doubleValue
    }

    if sender == widthField {
      selectedShape.frame.size.width = sender.doubleValue
    }

    if sender == heightField {
      selectedShape.frame.size.height = sender.doubleValue
    }

    shapesDocument.shapes = shapesDocument.shapes.map {
      if $0.id == selectedShape.id {
        return selectedShape
      } else {
        return $0
      }
    }

    delegate?.inspectorViewControllerSelectedShapeDidChange(self)
  }

  @IBAction func colorChanged(_ sender: NSColorWell) {
    guard var selectedShape = self.selectedShape else {
      return
    }

    selectedShape.color = colorWell.color.shapesColor

    shapesDocument.shapes = shapesDocument.shapes.map {
      if $0.id == selectedShape.id {
        return selectedShape
      } else {
        return $0
      }
    }

    delegate?.inspectorViewControllerSelectedShapeDidChange(self)
  }
}
