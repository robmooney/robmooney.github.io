// Created by Robert Mooney.
// Copyright © 2021 Robert Mooney.

import Cocoa

protocol CanvasViewControllerDelgate: AnyObject {
  func canvasViewControllerShapesDidChange(_ canvasViewController: CanvasViewController)
}

class CanvasViewController: NSViewController {
  weak var delegate : CanvasViewControllerDelgate?
  
  var canvasView: CanvasView {
    view as! CanvasView
  }

  var shapesDocument: ShapesDocument {
    get {
      representedObject as! ShapesDocument
    }
    set {
      representedObject = newValue
    }
  }

  override func viewDidLoad() {
    super.viewDidLoad()

    canvasView.delegate = self
  }
  
  override var representedObject: Any? {
    didSet {
      updateView()
    }
  }

  func updateView() {
    canvasView.shapes = shapesDocument.shapes
  }
}

extension CanvasViewController: CanvasViewDelegate {
  func canvasView(_ canvasView: CanvasView, didAddShape shape: Shape) {
    shapesDocument.shapes.append(shape)
    delegate?.canvasViewControllerShapesDidChange(self)
    updateView()
  }

  func canvasView(_ canvasView: CanvasView, didMouseDownOnShape shape: Shape) {
    shapesDocument.shapes = shapesDocument.shapes.map {
      var newShape = $0
      if newShape.id == shape.id {
        newShape.isSelected = true
      } else {
        newShape.isSelected = false
      }
      return newShape
    }
    delegate?.canvasViewControllerShapesDidChange(self)
    updateView()
  }

  func canvasView(_ canvasView: CanvasView, didDragShape shape: Shape) {
    shapesDocument.shapes = shapesDocument.shapes.map {
      if $0.id == shape.id {
        return shape
      } else {
        return $0
      }
    }
    delegate?.canvasViewControllerShapesDidChange(self)
    updateView()
  }

  func canvasView(_ canvasView: CanvasView, didMouseUpOnShape shape: Shape) {
    shapesDocument.shapes = shapesDocument.shapes.map {
      var newShape = $0
      newShape.isSelected = false
      return newShape
    }
  }
}
