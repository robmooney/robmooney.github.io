// Created by Robert Mooney.
// Copyright © 2021 Robert Mooney.

import Cocoa

class DocumentViewController: NSSplitViewController {
  var canvasViewController: CanvasViewController {
    splitViewItems[0].viewController as! CanvasViewController
  }

  var inspectorViewController: InspectorViewController {
    splitViewItems[1].viewController as! InspectorViewController
  }

  override func viewDidLoad() {
    super.viewDidLoad()

    splitViewItems.first?.minimumThickness = 400

    canvasViewController.delegate = self
    inspectorViewController.delegate = self
  }

  override var representedObject: Any? {
    didSet {
      canvasViewController.representedObject = representedObject
      inspectorViewController.representedObject = representedObject
    }
  }
}

extension DocumentViewController: CanvasViewControllerDelgate {
  func canvasViewControllerShapesDidChange(_ canvasViewController: CanvasViewController) {
    inspectorViewController.updateView()
  }
}

extension DocumentViewController: InspectorViewControllerDelgate {
  func inspectorViewControllerSelectedShapeDidChange(_ inspectorViewController: InspectorViewController) {
    canvasViewController.updateView()
  }
}
